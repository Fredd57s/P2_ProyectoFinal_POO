package com.mycompany.p2taller1chuicoedith;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
public class MongoInicio {
  private final MongoClient mongoClient;
    private final MongoDatabase database;
    private final MongoCollection<Document> collection;
    private final MongoCollection<Document> collectionn;
    public MongoInicio() {
        this.mongoClient = MongoClients.create("mongodb://localhost:27017");
        this.database = mongoClient.getDatabase("ProyectoDeliFrost");
        this.collection = database.getCollection("Inventario");
        this.collectionn = database.getCollection("Sabores");
    }
    public FindIterable<Document> getAllDocuments() {
        return collection.find();
    }
    public FindIterable<Document> getAllDocumentscollectionn() {
        return collectionn.find();
    }
    public void closeConnection() {
        mongoClient.close();
    }
}
