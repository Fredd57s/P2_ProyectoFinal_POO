package com.mycompany.p2taller1chuicoedith;
import com.mongodb.client.FindIterable;
import org.bson.Document;  
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class Inventario extends javax.swing.JFrame {
     private final MongoInicio mongoInicio;
     private final MongoNocom mongoNocom;
    public Inventario() {
        initComponents();
        
        mongoInicio = new MongoInicio();
        mongoNocom = new MongoNocom();
        cargarDatosDesdeMongo();
        cargarDatosDesdeMongoo();
        cargarDatosDesdeMongooo();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        jDialog2 = new javax.swing.JDialog();
        panel1 = new java.awt.Panel();
        jDialog3 = new javax.swing.JDialog();
        jFileChooser1 = new javax.swing.JFileChooser();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        GuardarC = new java.awt.Button();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        comestiblen = new javax.swing.JTextPane();
        jScrollPane4 = new javax.swing.JScrollPane();
        codigo = new javax.swing.JTextPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        stockC = new javax.swing.JTextPane();
        jScrollPane5 = new javax.swing.JScrollPane();
        Sabores = new javax.swing.JTable();
        button2 = new java.awt.Button();
        jLabel13 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        noComestibles2 = new javax.swing.JTextField();
        codigo1 = new javax.swing.JTextField();
        nstockC = new javax.swing.JTextField();
        GuardarNocom = new java.awt.Button();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        Aderezos = new javax.swing.JTable();
        ActualizarNocom = new java.awt.Button();
        jLabel24 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        button4 = new java.awt.Button();
        jTabbedPane5 = new javax.swing.JTabbedPane();
        jPanel4 = new javax.swing.JPanel();
        nuevoNombre = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        guardarNombre = new java.awt.Button();
        busqueda1 = new java.awt.Button();
        stock1 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTableNombre = new javax.swing.JTable();
        jLabel20 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        nuevostock = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        guardar = new java.awt.Button();
        stock = new javax.swing.JTextField();
        busqueda = new java.awt.Button();
        jLabel3 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        jTableStock = new javax.swing.JTable();
        jLabel14 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        eliminar = new java.awt.Button();
        codel = new javax.swing.JTextField();
        busquedaelim = new java.awt.Button();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        jTableEliminar = new javax.swing.JTable();
        jLabel27 = new javax.swing.JLabel();
        button1 = new java.awt.Button();

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jDialog2Layout = new javax.swing.GroupLayout(jDialog2.getContentPane());
        jDialog2.getContentPane().setLayout(jDialog2Layout);
        jDialog2Layout.setHorizontalGroup(
            jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog2Layout.setVerticalGroup(
            jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jDialog3Layout = new javax.swing.GroupLayout(jDialog3.getContentPane());
        jDialog3.getContentPane().setLayout(jDialog3Layout);
        jDialog3Layout.setHorizontalGroup(
            jDialog3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog3Layout.setVerticalGroup(
            jDialog3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setLayout(null);

        GuardarC.setBackground(new java.awt.Color(204, 204, 204));
        GuardarC.setFont(new java.awt.Font("Eras Demi ITC", 1, 12)); // NOI18N
        GuardarC.setLabel("Guardar");
        GuardarC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuardarCActionPerformed(evt);
            }
        });
        jPanel2.add(GuardarC);
        GuardarC.setBounds(140, 280, 68, 22);

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Wide Latin", 1, 14)); // NOI18N
        jLabel5.setText("Registro de Sabores ");
        jPanel2.add(jLabel5);
        jLabel5.setBounds(240, 0, 260, 50);

        jLabel4.setText("Nombre del Sabor");
        jPanel2.add(jLabel4);
        jLabel4.setBounds(130, 80, 160, 14);

        jLabel1.setText("Código del sabor:");
        jPanel2.add(jLabel1);
        jLabel1.setBounds(130, 140, 160, 16);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 2, 8)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 0, 0));
        jLabel2.setText("Una letra acompañada de tres numeros");
        jPanel2.add(jLabel2);
        jLabel2.setBounds(440, 160, 135, 11);

        jLabel10.setText("Porciones disponibles");
        jPanel2.add(jLabel10);
        jLabel10.setBounds(120, 210, 160, 16);

        jScrollPane1.setViewportView(comestiblen);

        jPanel2.add(jScrollPane1);
        jScrollPane1.setBounds(400, 70, 235, 30);

        jScrollPane4.setViewportView(codigo);

        jPanel2.add(jScrollPane4);
        jScrollPane4.setBounds(400, 130, 235, 30);

        jScrollPane2.setViewportView(stockC);

        jPanel2.add(jScrollPane2);
        jScrollPane2.setBounds(400, 210, 235, 30);

        Sabores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane5.setViewportView(Sabores);

        jPanel2.add(jScrollPane5);
        jScrollPane5.setBounds(140, 360, 440, 150);

        button2.setBackground(new java.awt.Color(255, 255, 255));
        button2.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        button2.setForeground(new java.awt.Color(0, 0, 0));
        button2.setLabel("Actualizar");
        button2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button2ActionPerformed(evt);
            }
        });
        jPanel2.add(button2);
        button2.setBounds(440, 280, 73, 24);

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setText("Sabores Totales");
        jPanel2.add(jLabel13);
        jLabel13.setBounds(300, 330, 120, 25);

        jTabbedPane1.addTab("Sabores de Helado", jPanel2);

        jPanel1.setLayout(null);

        jLabel15.setBackground(new java.awt.Color(255, 255, 255));
        jLabel15.setFont(new java.awt.Font("Wide Latin", 1, 14)); // NOI18N
        jLabel15.setText("Registro de Aderezos");
        jPanel1.add(jLabel15);
        jLabel15.setBounds(280, 10, 260, 40);

        jLabel16.setText("Nombre del aderezo:");
        jPanel1.add(jLabel16);
        jLabel16.setBounds(180, 80, 140, 14);

        noComestibles2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                noComestibles2ActionPerformed(evt);
            }
        });
        jPanel1.add(noComestibles2);
        noComestibles2.setBounds(410, 70, 200, 30);

        codigo1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                codigo1ActionPerformed(evt);
            }
        });
        jPanel1.add(codigo1);
        codigo1.setBounds(410, 120, 200, 30);

        nstockC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nstockCActionPerformed(evt);
            }
        });
        jPanel1.add(nstockC);
        nstockC.setBounds(410, 180, 200, 30);

        GuardarNocom.setBackground(new java.awt.Color(255, 255, 255));
        GuardarNocom.setFont(new java.awt.Font("Eras Demi ITC", 0, 12)); // NOI18N
        GuardarNocom.setLabel("Guardar");
        GuardarNocom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuardarNocomActionPerformed(evt);
            }
        });
        jPanel1.add(GuardarNocom);
        GuardarNocom.setBounds(180, 250, 61, 24);

        jLabel17.setText("Código del aderezo:");
        jPanel1.add(jLabel17);
        jLabel17.setBounds(180, 130, 130, 20);

        jLabel18.setFont(new java.awt.Font("Segoe UI", 2, 8)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 0, 0));
        jLabel18.setText("Una letra acompañada de tres numeros");
        jPanel1.add(jLabel18);
        jLabel18.setBounds(430, 150, 150, 11);

        jLabel19.setText("Porciones:");
        jPanel1.add(jLabel19);
        jLabel19.setBounds(180, 190, 130, 14);

        Aderezos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane6.setViewportView(Aderezos);

        jPanel1.add(jScrollPane6);
        jScrollPane6.setBounds(100, 330, 560, 180);

        ActualizarNocom.setBackground(new java.awt.Color(255, 255, 255));
        ActualizarNocom.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        ActualizarNocom.setForeground(new java.awt.Color(0, 0, 0));
        ActualizarNocom.setLabel("Actualizar");
        ActualizarNocom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ActualizarNocomActionPerformed(evt);
            }
        });
        jPanel1.add(ActualizarNocom);
        ActualizarNocom.setBounds(510, 250, 73, 24);

        jLabel24.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel24.setText("Aderezos Totales");
        jPanel1.add(jLabel24);
        jLabel24.setBounds(320, 300, 130, 20);

        jTabbedPane1.addTab("Aderezos", jPanel1);

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(jTable3);

        button4.setBackground(new java.awt.Color(255, 255, 255));
        button4.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        button4.setForeground(new java.awt.Color(0, 0, 0));
        button4.setLabel("Actualizar");
        button4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button4ActionPerformed(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(null);

        nuevoNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nuevoNombreActionPerformed(evt);
            }
        });
        jPanel4.add(nuevoNombre);
        nuevoNombre.setBounds(350, 160, 143, 22);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setText("Ingrese el nuevo nombre: ");
        jPanel4.add(jLabel6);
        jLabel6.setBounds(200, 160, 146, 16);

        guardarNombre.setBackground(new java.awt.Color(255, 255, 255));
        guardarNombre.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        guardarNombre.setForeground(new java.awt.Color(0, 0, 0));
        guardarNombre.setLabel("Guardar ");
        guardarNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarNombreActionPerformed(evt);
            }
        });
        jPanel4.add(guardarNombre);
        guardarNombre.setBounds(520, 160, 65, 24);

        busqueda1.setBackground(new java.awt.Color(255, 255, 255));
        busqueda1.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        busqueda1.setForeground(new java.awt.Color(0, 0, 0));
        busqueda1.setLabel("Buscar ");
        busqueda1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                busqueda1ActionPerformed(evt);
            }
        });
        jPanel4.add(busqueda1);
        busqueda1.setBounds(630, 40, 60, 24);
        jPanel4.add(stock1);
        stock1.setBounds(410, 40, 204, 22);

        jLabel7.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel7.setText("Cambio de Nombre del Producto");
        jPanel4.add(jLabel7);
        jLabel7.setBounds(20, 10, 310, 20);

        jLabel8.setFont(new java.awt.Font("Perpetua", 1, 14)); // NOI18N
        jLabel8.setText("Ingrese porfavor el código del producto que desee modificar");
        jPanel4.add(jLabel8);
        jLabel8.setBounds(30, 40, 380, 17);

        jTableNombre.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Código", "Producto", "Stock", "Precio"
            }
        ));
        jScrollPane7.setViewportView(jTableNombre);

        jPanel4.add(jScrollPane7);
        jScrollPane7.setBounds(180, 80, 452, 40);

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icononombre.jpg"))); // NOI18N
        jPanel4.add(jLabel20);
        jLabel20.setBounds(50, 60, 90, 90);

        jTabbedPane5.addTab("Nombre", jPanel4);

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setLayout(null);

        nuevostock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nuevostockActionPerformed(evt);
            }
        });
        jPanel6.add(nuevostock);
        nuevostock.setBounds(350, 160, 143, 22);

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel22.setText("Ingrese el nuevo stock: ");
        jPanel6.add(jLabel22);
        jLabel22.setBounds(200, 160, 132, 16);

        guardar.setBackground(new java.awt.Color(255, 255, 255));
        guardar.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        guardar.setForeground(new java.awt.Color(0, 0, 0));
        guardar.setLabel("Guardar ");
        guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarActionPerformed(evt);
            }
        });
        jPanel6.add(guardar);
        guardar.setBounds(520, 160, 65, 24);
        jPanel6.add(stock);
        stock.setBounds(410, 40, 204, 22);

        busqueda.setBackground(new java.awt.Color(255, 255, 255));
        busqueda.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        busqueda.setForeground(new java.awt.Color(0, 0, 0));
        busqueda.setLabel("Buscar ");
        busqueda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                busquedaActionPerformed(evt);
            }
        });
        jPanel6.add(busqueda);
        busqueda.setBounds(630, 40, 60, 24);

        jLabel3.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel3.setText("Cambio de Porciones");
        jPanel6.add(jLabel3);
        jLabel3.setBounds(20, 10, 230, 20);

        jLabel23.setFont(new java.awt.Font("Perpetua", 1, 14)); // NOI18N
        jLabel23.setText("Ingrese porfavor el código del producto que desee modificar");
        jPanel6.add(jLabel23);
        jLabel23.setBounds(30, 40, 380, 17);

        jTableStock.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Código", "Producto", "Stock", "Precio"
            }
        ));
        jScrollPane9.setViewportView(jTableStock);

        jPanel6.add(jScrollPane9);
        jScrollPane9.setBounds(180, 80, 452, 40);

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/iconoCStock.jpg"))); // NOI18N
        jPanel6.add(jLabel14);
        jLabel14.setBounds(60, 70, 80, 80);

        jTabbedPane5.addTab("Stock\n", jPanel6);

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setLayout(null);

        eliminar.setBackground(new java.awt.Color(255, 255, 255));
        eliminar.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        eliminar.setForeground(new java.awt.Color(0, 0, 0));
        eliminar.setLabel("Eliminar\n");
        eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarActionPerformed(evt);
            }
        });
        jPanel7.add(eliminar);
        eliminar.setBounds(390, 130, 62, 24);
        jPanel7.add(codel);
        codel.setBounds(410, 40, 204, 22);

        busquedaelim.setBackground(new java.awt.Color(255, 255, 255));
        busquedaelim.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        busquedaelim.setForeground(new java.awt.Color(0, 0, 0));
        busquedaelim.setLabel("Buscar ");
        busquedaelim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                busquedaelimActionPerformed(evt);
            }
        });
        jPanel7.add(busquedaelim);
        busquedaelim.setBounds(630, 40, 60, 24);

        jLabel25.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel25.setText("Eliminar Producto");
        jPanel7.add(jLabel25);
        jLabel25.setBounds(20, 10, 190, 20);

        jLabel26.setFont(new java.awt.Font("Perpetua", 1, 14)); // NOI18N
        jLabel26.setText("Ingrese porfavor el código del producto que desee eliminar");
        jPanel7.add(jLabel26);
        jLabel26.setBounds(30, 40, 380, 17);

        jTableEliminar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Código", "Producto", "Stock", "Precio"
            }
        ));
        jScrollPane10.setViewportView(jTableEliminar);

        jPanel7.add(jScrollPane10);
        jScrollPane10.setBounds(180, 80, 452, 40);

        jLabel27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/iconoElim.jpg"))); // NOI18N
        jPanel7.add(jLabel27);
        jLabel27.setBounds(40, 70, 80, 80);

        jTabbedPane5.addTab("Eliminar", jPanel7);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 630, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(690, 690, 690)
                        .addComponent(button4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jTabbedPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 790, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(button4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(jTabbedPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Modificar Inventario", jPanel3);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 810, 580));

        button1.setBackground(new java.awt.Color(204, 204, 204));
        button1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        button1.setFont(new java.awt.Font("Eras Demi ITC", 1, 12)); // NOI18N
        button1.setForeground(new java.awt.Color(0, 0, 0));
        button1.setLabel("Volver al menu");
        button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1ActionPerformed(evt);
            }
        });
        getContentPane().add(button1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1ActionPerformed
        Menu m = new Menu();
        m.setVisible(true); 
        m.setLocationRelativeTo(null);// TODO add your handling code here:
        setVisible(false);
    }//GEN-LAST:event_button1ActionPerformed
    private void GuardarCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuardarCActionPerformed
        try{
        String nombreC=comestiblen.getText();
        String stock=stockC.getText();
        String codi=codigo.getText();
        
    if (nombreC.isEmpty() || stock.isEmpty() || codi.isEmpty() ) {
        JOptionPane.showMessageDialog(this, "Todos los campos deben ser completados", "Error", JOptionPane.ERROR_MESSAGE);
        return; // Salir del método si hay campos vacíos
        }
        
    if (!codi.matches("[a-z]\\d{3}")) {
    JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
    return;
    }
    
    try {
    int stockValue = Integer.parseInt(stock);
    if (stockValue < 1 || stockValue > 1000) {
        JOptionPane.showMessageDialog(this, "Ingrese un valor de stock válido (entre 1 y 1000)", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
} catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(this, "Ingrese un valor numérico válido para el stock", "Error", JOptionPane.ERROR_MESSAGE);
    return;
}

     try(MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017")) {
                MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
                MongoCollection<Document> collection = database.getCollection("Sabores");
                MongoCollection<Document> collectionn = database.getCollection("Inventario");
                 Document query = new Document("Código:", codi);
        long count = collection.countDocuments(query);
       if( count <= 0){
        }else {
            JOptionPane.showMessageDialog(this, "El codigo ya existe dentro de los datos ingresados, por favor ingrese un codigo distinto", "Error", JOptionPane.ERROR_MESSAGE);
            return;
       }
                    String resultado = nombreC.substring(0, 1).toUpperCase() + nombreC.substring(1).toLowerCase();
                    Document document = new Document()
                        .append("Producto:", resultado)
                        .append("Código:", codi)
                        .append("Porciones:", stock);
                        collection.insertOne(document);
                    Document documentAr = new Document()
                        .append("Producto:", resultado)
                        .append("Código:", codi)
                        .append("Porciones:", stock);
                     
                collectionn.insertOne(documentAr);
                JOptionPane.showMessageDialog(this, "Datos guardados correctamente en la base de datos", "Éxito", JOptionPane.INFORMATION_MESSAGE);
         }}  catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Ingrese valores numéricos válidos para Stock y Precio", "Error", JOptionPane.ERROR_MESSAGE);
         }
        comestiblen.setText("");
        stockC.setText("");
        codigo.setText("");
    }//GEN-LAST:event_GuardarCActionPerformed

    private void button2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button2ActionPerformed
        cargarDatosDesdeMongo();
        JOptionPane.showMessageDialog(this, "Tabla actualizada!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        // TODO add your handling code here:
    }//GEN-LAST:event_button2ActionPerformed
    private void cargarDatosDesdeMongoo() {
         FindIterable<Document> documents = mongoNocom.getAllDocumentscollectionn();
         DefaultTableModel tableModel = new DefaultTableModel();
         tableModel.setColumnIdentifiers(new String[]{ "Código de Producto","Producto","Porciones"});
         for (Document document : documents) {
             tableModel.addRow(new Object[]{
                 document.get("Código:"),
                 document.get("Producto:"),
                 document.get("Porciones:")
             });
         }
         Aderezos.setModel(tableModel);
    }
    private void noComestibles2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_noComestibles2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_noComestibles2ActionPerformed

    private void codigo1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_codigo1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_codigo1ActionPerformed

    private void nstockCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nstockCActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nstockCActionPerformed

    private void GuardarNocomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuardarNocomActionPerformed
        String nombreC=noComestibles2.getText();
        String stock1=nstockC.getText();
        String cod=codigo1.getText();
        if (nombreC.isEmpty() || cod.isEmpty() ||stock1.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos deben ser completados", "Error", JOptionPane.ERROR_MESSAGE);
            return;}
        if (!cod.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            int stockr = Integer.parseInt(stock1);
            if (stockr < 1 || stockr > 1000) {
                JOptionPane.showMessageDialog(this, "La cantidad de stock debe ser un número positivo entre 1 y 1000", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La cantidad de stock debe ser un número válido entre 1 y 1000", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        
        try(MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017")) {
            MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
            MongoCollection<Document> collection = database.getCollection("Aderezos");
            MongoCollection<Document> collectionn = database.getCollection("Inventario");
            Document query = new Document("Código de Producto:", cod);
            long count = collection.countDocuments(query);
            if( count <= 0){
            }else {
                JOptionPane.showMessageDialog(this, "El codigo ya existe dentro de los datos ingresados, por favor ingrese un codigo distinto", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String resultado = nombreC.substring(0, 1).toUpperCase() + nombreC.substring(1).toLowerCase();

            Document document = new Document()
            .append("Producto:", resultado)
            .append("Código:", cod)
            .append("Porciones:", stock1);
            collection.insertOne(document);
            collectionn.insertOne(document);
            JOptionPane.showMessageDialog(this, "Datos guardados correctamente en la base de datos", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        }  catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Ingrese valores numéricos válidos para Stock y Precio", "Error", JOptionPane.ERROR_MESSAGE);
        }
        noComestibles2.setText("");
        nstockC.setText("");
        codigo.setText("");
    }//GEN-LAST:event_GuardarNocomActionPerformed

    private void ActualizarNocomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ActualizarNocomActionPerformed
        cargarDatosDesdeMongoo();
        JOptionPane.showMessageDialog(this, "Tabla actualizada!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        // TODO add your handling code here:
    }//GEN-LAST:event_ActualizarNocomActionPerformed

    private void button4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button4ActionPerformed
        cargarDatosDesdeMongooo();
        JOptionPane.showMessageDialog(this, "Tabla actualizada!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        // TODO add your handling code here:
    }//GEN-LAST:event_button4ActionPerformed

    private void nuevoNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nuevoNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nuevoNombreActionPerformed

    private void guardarNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarNombreActionPerformed
        String codd = stock1.getText();
        String nuevoNom = nuevoNombre.getText();
        String Nombre = nuevoNom.substring(0, 1).toUpperCase() + nuevoNom.substring(1).toLowerCase();

        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collectionn = database.getCollection("Inventario");
        MongoCollection<Document> collection = database.getCollection("Aderezos");
        MongoCollection<Document> collectionnn = database.getCollection("Sabores");

        Document query = new Document("Código:", codd);
        long count = collectionn.countDocuments(query);
        Document queryy = new Document("Producto:", Nombre);
        long counnt = collectionn.countDocuments(queryy);

        if (count <= 0) {
            JOptionPane.showMessageDialog(this, "El código ingresado no ha sido registrado", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            if(counnt <= 0){

                // Define la actualización que deseas realizar
                Document updateDocument = new Document("$set", new Document("Producto:", Nombre));
                // Realiza la actualización
                collectionn.updateOne(query, updateDocument);
                collection.updateOne(query, updateDocument);
                collectionnn.updateOne(query, updateDocument);
                JOptionPane.showMessageDialog(this, "Nombre del producto actualizado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(this, "El nombre ingresado ya existe para otro producto", "Error", JOptionPane.ERROR_MESSAGE);
            }}
            stock1.setText("");
            nuevoNombre.setText("");
    }//GEN-LAST:event_guardarNombreActionPerformed

    private void busqueda1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_busqueda1ActionPerformed
        String codd = stock1.getText();
        if (!codd.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collectionn = database.getCollection("Inventario");

        Document query = new Document("Código:", codd);
        long count = collectionn.countDocuments(query);
        if (count <= 0) {
            JOptionPane.showMessageDialog(this, "El código ingresado no a sido registrado", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            DefaultTableModel tableModel = (DefaultTableModel) jTableNombre.getModel();
            tableModel.setRowCount(0);
            FindIterable<Document> documents = collectionn.find(query);
            for (Document document : documents) {
                tableModel.addRow(new Object[]{
                    document.get("Código:"),
                    document.get("Producto:"),
                    document.get("Porciones:")
                });  }
                jTableNombre.setModel(tableModel);
                jTableNombre.revalidate();
                jTableNombre.repaint();
            }  // TODO add your handling code here:
    }//GEN-LAST:event_busqueda1ActionPerformed

    private void nuevostockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nuevostockActionPerformed

    }//GEN-LAST:event_nuevostockActionPerformed

    private void guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarActionPerformed
        String cod = stock.getText();
        String nuevoStock = nuevostock.getText();
        try {
            int stockr = Integer.parseInt(nuevoStock);
            if (stockr < 1 || stockr > 1000) {
                JOptionPane.showMessageDialog(this, "La cantidad de stock debe ser un número positivo entre 1 y 1000", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La cantidad de stock debe ser un número válido entre 1 y 1000", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collectionn = database.getCollection("Inventario");
        MongoCollection<Document> collection = database.getCollection("Sabores");
        MongoCollection<Document> collectionnn = database.getCollection("Aderezos");
        Document query = new Document("Código:", cod);
        long count = collectionn.countDocuments(query);
        if (count <= 0) {
            JOptionPane.showMessageDialog(this, "El código ingresado no ha sido registrado", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            Document updateDocument = new Document("$set", new Document("Porciones:", nuevoStock));
            collectionn.updateOne(query, updateDocument);
            collection.updateOne(query, updateDocument);
            collectionnn.updateOne(query, updateDocument);
            JOptionPane.showMessageDialog(this, "Porciones totales actualizadas correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
        stock.setText("");
        nuevostock.setText("");
    }//GEN-LAST:event_guardarActionPerformed

    private void busquedaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_busquedaActionPerformed
        String cod = stock.getText();
        if (!cod.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collectionn = database.getCollection("Inventario");

        Document query = new Document("Código:", cod);
        long count = collectionn.countDocuments(query);
        if (count <= 0) {
            JOptionPane.showMessageDialog(this, "El código ingresado no a sido registrado", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            DefaultTableModel tableModel = (DefaultTableModel) jTableStock.getModel();
            tableModel.setRowCount(0);
            FindIterable<Document> documents = collectionn.find(query);
            for (Document document : documents) {
                tableModel.addRow(new Object[]{
                    document.get("Código:"),
                    document.get("Producto:"),
                    document.get("Porciones:")
                });
            }
            jTableStock.setModel(tableModel);
            jTableStock.revalidate();
            jTableStock.repaint();
        }
    }//GEN-LAST:event_busquedaActionPerformed

    private void eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarActionPerformed
        String cod = codel.getText();
        if (!cod.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }try (MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017")) {
            MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
            MongoCollection<Document> collection = database.getCollection("Inventario");
            MongoCollection<Document> collectionn = database.getCollection("Sabores");
            MongoCollection<Document> collectionnn = database.getCollection("Aderezos");
            Document filter = new Document("Código:", cod);
            collection.deleteOne(filter);
            collectionn.deleteOne(filter);
            collectionnn.deleteOne(filter);
            JOptionPane.showMessageDialog(this, "El producto a sido eliminado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_eliminarActionPerformed

    private void busquedaelimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_busquedaelimActionPerformed
        String cod = codel.getText();
        if (!cod.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collectionn = database.getCollection("Inventario");

        Document query = new Document("Código:", cod);
        long count = collectionn.countDocuments(query);
        if (count <= 0) {
            JOptionPane.showMessageDialog(this, "El código ingresado no a sido registrado", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            DefaultTableModel tableModel = (DefaultTableModel) jTableEliminar.getModel();
            tableModel.setRowCount(0);
            FindIterable<Document> documents = collectionn.find(query);
            for (Document document : documents) {
                tableModel.addRow(new Object[]{
                    document.get("Código:"),
                    document.get("Producto:"),
                    document.get("Porciones:")
                });
            }
            jTableEliminar.setModel(tableModel);
            jTableEliminar.revalidate();
            jTableEliminar.repaint();
        }        // TODO add your handling code here:
    }//GEN-LAST:event_busquedaelimActionPerformed
    private void cargarDatosDesdeMongooo() {
         FindIterable<Document> documents = mongoNocom.getAllDocumentscollection();
         DefaultTableModel tableModel = new DefaultTableModel();
         tableModel.setColumnIdentifiers(new String[]{ "Código de Producto","Producto","Stock"});
         // Llena el modelo con los datos de MongoDB
         for (Document document : documents) {
             tableModel.addRow(new Object[]{
                 document.get("Código:"),
                 document.get("Producto:"),
                 document.get("Porciones:")
             });} jTable3.setModel(tableModel);
    }
    private void cargarDatosDesdeMongo() {
         FindIterable<Document> documents = mongoInicio.getAllDocumentscollectionn();
         DefaultTableModel tableModel = new DefaultTableModel();
         tableModel.setColumnIdentifiers(new String[]{ "Código","Producto","Porciones"});
         for (Document document : documents) {
             tableModel.addRow(new Object[]{
                 document.get("Código:"),
                 document.get("Producto:"),
                 document.get("Porciones:")
             });}
         Sabores.setModel(tableModel);
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Inventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Inventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Inventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inventario().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button ActualizarNocom;
    private javax.swing.JTable Aderezos;
    private java.awt.Button GuardarC;
    private java.awt.Button GuardarNocom;
    private javax.swing.JTable Sabores;
    private java.awt.Button busqueda;
    private java.awt.Button busqueda1;
    private java.awt.Button busquedaelim;
    private java.awt.Button button1;
    private java.awt.Button button2;
    private java.awt.Button button4;
    private javax.swing.JTextField codel;
    private javax.swing.JTextPane codigo;
    private javax.swing.JTextField codigo1;
    private javax.swing.JTextPane comestiblen;
    private java.awt.Button eliminar;
    private java.awt.Button guardar;
    private java.awt.Button guardarNombre;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JDialog jDialog2;
    private javax.swing.JDialog jDialog3;
    private javax.swing.JFileChooser jFileChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane5;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTableEliminar;
    private javax.swing.JTable jTableNombre;
    private javax.swing.JTable jTableStock;
    private javax.swing.JTextField noComestibles2;
    private javax.swing.JTextField nstockC;
    private javax.swing.JTextField nuevoNombre;
    private javax.swing.JTextField nuevostock;
    private java.awt.Panel panel1;
    private javax.swing.JTextField stock;
    private javax.swing.JTextField stock1;
    private javax.swing.JTextPane stockC;
    // End of variables declaration//GEN-END:variables
}