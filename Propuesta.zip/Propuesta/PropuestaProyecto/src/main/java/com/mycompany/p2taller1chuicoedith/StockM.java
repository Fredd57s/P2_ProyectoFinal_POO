package com.mycompany.p2taller1chuicoedith;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;
public class StockM extends javax.swing.JFrame {
    private final MongoNocom mongoNocom;
    public StockM() {
        initComponents();
        mongoNocom = new MongoNocom();
        cargarDatosDesdeMongoo();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        button2 = new java.awt.Button();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane5 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        nuevoNombre = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        guardarNombre = new java.awt.Button();
        busqueda1 = new java.awt.Button();
        stock1 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTableNombre = new javax.swing.JTable();
        jLabel13 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        nuevoPrecio = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        guardarPrecio = new java.awt.Button();
        busqueda2 = new java.awt.Button();
        cod3 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTablePrecio = new javax.swing.JTable();
        jLabel12 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        nuevostock = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        guardar = new java.awt.Button();
        stock = new javax.swing.JTextField();
        busqueda = new java.awt.Button();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableStock = new javax.swing.JTable();
        jLabel14 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        eliminar = new java.awt.Button();
        codel = new javax.swing.JTextField();
        busquedaelim = new java.awt.Button();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTableEliminar = new javax.swing.JTable();
        jLabel18 = new javax.swing.JLabel();
        button1 = new java.awt.Button();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().setLayout(null);

        jPanel3.setLayout(null);
        getContentPane().add(jPanel3);
        jPanel3.setBounds(0, 0, 0, 0);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(70, 40, 630, 190);

        button2.setBackground(new java.awt.Color(255, 255, 255));
        button2.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        button2.setForeground(new java.awt.Color(0, 0, 0));
        button2.setLabel("Actualizar");
        button2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button2ActionPerformed(evt);
            }
        });
        getContentPane().add(button2);
        button2.setBounds(690, 240, 73, 24);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Inventario de Productos Disponibles");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(230, 10, 340, 25);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(null);

        nuevoNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nuevoNombreActionPerformed(evt);
            }
        });
        jPanel2.add(nuevoNombre);
        nuevoNombre.setBounds(350, 160, 143, 22);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setText("Ingrese el nuevo nombre: ");
        jPanel2.add(jLabel6);
        jLabel6.setBounds(200, 160, 146, 16);

        guardarNombre.setBackground(new java.awt.Color(255, 255, 255));
        guardarNombre.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        guardarNombre.setForeground(new java.awt.Color(0, 0, 0));
        guardarNombre.setLabel("Guardar ");
        guardarNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarNombreActionPerformed(evt);
            }
        });
        jPanel2.add(guardarNombre);
        guardarNombre.setBounds(520, 160, 65, 24);

        busqueda1.setBackground(new java.awt.Color(255, 255, 255));
        busqueda1.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        busqueda1.setForeground(new java.awt.Color(0, 0, 0));
        busqueda1.setLabel("Buscar ");
        busqueda1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                busqueda1ActionPerformed(evt);
            }
        });
        jPanel2.add(busqueda1);
        busqueda1.setBounds(630, 40, 60, 24);
        jPanel2.add(stock1);
        stock1.setBounds(410, 40, 204, 22);

        jLabel7.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel7.setText("Cambio de Nombre del Producto");
        jPanel2.add(jLabel7);
        jLabel7.setBounds(20, 10, 310, 20);

        jLabel8.setFont(new java.awt.Font("Perpetua", 1, 14)); // NOI18N
        jLabel8.setText("Ingrese porfavor el código del producto que desee modificar");
        jPanel2.add(jLabel8);
        jLabel8.setBounds(30, 40, 380, 17);

        jTableNombre.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Código", "Producto", "Stock", "Precio"
            }
        ));
        jScrollPane3.setViewportView(jTableNombre);

        jPanel2.add(jScrollPane3);
        jScrollPane3.setBounds(180, 80, 452, 40);

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icononombre.jpg"))); // NOI18N
        jPanel2.add(jLabel13);
        jLabel13.setBounds(50, 60, 90, 90);

        jTabbedPane5.addTab("Nombre", jPanel2);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(null);

        nuevoPrecio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nuevoPrecioActionPerformed(evt);
            }
        });
        jPanel4.add(nuevoPrecio);
        nuevoPrecio.setBounds(350, 160, 143, 22);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setText("Ingrese el nuevo precio: ");
        jPanel4.add(jLabel9);
        jLabel9.setBounds(200, 160, 140, 16);

        guardarPrecio.setBackground(new java.awt.Color(255, 255, 255));
        guardarPrecio.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        guardarPrecio.setForeground(new java.awt.Color(0, 0, 0));
        guardarPrecio.setLabel("Guardar ");
        guardarPrecio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarPrecioActionPerformed(evt);
            }
        });
        jPanel4.add(guardarPrecio);
        guardarPrecio.setBounds(520, 160, 65, 24);

        busqueda2.setBackground(new java.awt.Color(255, 255, 255));
        busqueda2.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        busqueda2.setForeground(new java.awt.Color(0, 0, 0));
        busqueda2.setLabel("Buscar ");
        busqueda2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                busqueda2ActionPerformed(evt);
            }
        });
        jPanel4.add(busqueda2);
        busqueda2.setBounds(630, 40, 60, 24);
        jPanel4.add(cod3);
        cod3.setBounds(410, 40, 204, 22);

        jLabel10.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel10.setText("Cambio de Precio del Producto");
        jPanel4.add(jLabel10);
        jLabel10.setBounds(20, 10, 310, 20);

        jLabel11.setFont(new java.awt.Font("Perpetua", 1, 14)); // NOI18N
        jLabel11.setText("Ingrese porfavor el código del producto que desee modificar");
        jPanel4.add(jLabel11);
        jLabel11.setBounds(30, 40, 380, 17);

        jTablePrecio.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Código", "Producto", "Stock", "Precio"
            }
        ));
        jScrollPane4.setViewportView(jTablePrecio);

        jPanel4.add(jScrollPane4);
        jScrollPane4.setBounds(180, 80, 452, 40);

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/iconoprecio.jpg"))); // NOI18N
        jPanel4.add(jLabel12);
        jLabel12.setBounds(60, 60, 80, 80);

        jTabbedPane5.addTab("Precio", jPanel4);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(null);

        nuevostock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nuevostockActionPerformed(evt);
            }
        });
        jPanel1.add(nuevostock);
        nuevostock.setBounds(350, 160, 143, 22);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setText("Ingrese el nuevo stock: ");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(200, 160, 132, 16);

        guardar.setBackground(new java.awt.Color(255, 255, 255));
        guardar.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        guardar.setForeground(new java.awt.Color(0, 0, 0));
        guardar.setLabel("Guardar ");
        guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarActionPerformed(evt);
            }
        });
        jPanel1.add(guardar);
        guardar.setBounds(520, 160, 65, 24);
        jPanel1.add(stock);
        stock.setBounds(410, 40, 204, 22);

        busqueda.setBackground(new java.awt.Color(255, 255, 255));
        busqueda.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        busqueda.setForeground(new java.awt.Color(0, 0, 0));
        busqueda.setLabel("Buscar ");
        busqueda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                busquedaActionPerformed(evt);
            }
        });
        jPanel1.add(busqueda);
        busqueda.setBounds(630, 40, 60, 24);

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel2.setText("Cambio de Stock");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(20, 10, 190, 20);

        jLabel3.setFont(new java.awt.Font("Perpetua", 1, 14)); // NOI18N
        jLabel3.setText("Ingrese porfavor el código del producto que desee modificar");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(30, 40, 380, 17);

        jTableStock.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Código", "Producto", "Stock", "Precio"
            }
        ));
        jScrollPane2.setViewportView(jTableStock);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(180, 80, 452, 40);

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/iconoCStock.jpg"))); // NOI18N
        jPanel1.add(jLabel14);
        jLabel14.setBounds(60, 70, 80, 80);

        jTabbedPane5.addTab("Stock\n", jPanel1);

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setLayout(null);

        eliminar.setBackground(new java.awt.Color(255, 255, 255));
        eliminar.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        eliminar.setForeground(new java.awt.Color(0, 0, 0));
        eliminar.setLabel("Eliminar\n");
        eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarActionPerformed(evt);
            }
        });
        jPanel6.add(eliminar);
        eliminar.setBounds(390, 130, 62, 24);
        jPanel6.add(codel);
        codel.setBounds(410, 40, 204, 22);

        busquedaelim.setBackground(new java.awt.Color(255, 255, 255));
        busquedaelim.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        busquedaelim.setForeground(new java.awt.Color(0, 0, 0));
        busquedaelim.setLabel("Buscar ");
        busquedaelim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                busquedaelimActionPerformed(evt);
            }
        });
        jPanel6.add(busquedaelim);
        busquedaelim.setBounds(630, 40, 60, 24);

        jLabel16.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel16.setText("Eliminar Producto");
        jPanel6.add(jLabel16);
        jLabel16.setBounds(20, 10, 190, 20);

        jLabel17.setFont(new java.awt.Font("Perpetua", 1, 14)); // NOI18N
        jLabel17.setText("Ingrese porfavor el código del producto que desee eliminar");
        jPanel6.add(jLabel17);
        jLabel17.setBounds(30, 40, 380, 17);

        jTableEliminar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Código", "Producto", "Stock", "Precio"
            }
        ));
        jScrollPane5.setViewportView(jTableEliminar);

        jPanel6.add(jScrollPane5);
        jScrollPane5.setBounds(180, 80, 452, 40);

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/iconoElim.jpg"))); // NOI18N
        jPanel6.add(jLabel18);
        jLabel18.setBounds(40, 70, 80, 80);

        jTabbedPane5.addTab("Eliminar", jPanel6);

        getContentPane().add(jTabbedPane5);
        jTabbedPane5.setBounds(0, 270, 790, 640);

        button1.setBackground(new java.awt.Color(255, 255, 255));
        button1.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        button1.setForeground(new java.awt.Color(0, 0, 0));
        button1.setLabel("Volver al Menu");
        button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1ActionPerformed(evt);
            }
        });
        getContentPane().add(button1);
        button1.setBounds(10, 10, 99, 20);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1ActionPerformed
    Menu m = new Menu();
        m.setVisible(true);  
        m.setLocationRelativeTo(null);// TODO add your handling code here:
        setVisible(false);        // TODO add your handling code here:
    }//GEN-LAST:event_button1ActionPerformed
    private void button2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button2ActionPerformed
        cargarDatosDesdeMongoo();
    JOptionPane.showMessageDialog(this, "Tabla actualizada!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
    // TODO add your handling code here:
    }//GEN-LAST:event_button2ActionPerformed
    private void busquedaelimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_busquedaelimActionPerformed
    String cod = codel.getText();
        if (!cod.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("InterfacesLab2");
        MongoCollection<Document> collectionn = database.getCollection("Archivos");

        Document query = new Document("Código de Producto:", cod);
        long count = collectionn.countDocuments(query);
        if (count <= 0) {
            JOptionPane.showMessageDialog(this, "El código ingresado no a sido registrado", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            DefaultTableModel tableModel = (DefaultTableModel) jTableEliminar.getModel();
            tableModel.setRowCount(0);
            FindIterable<Document> documents = collectionn.find(query);
            for (Document document : documents) {
                tableModel.addRow(new Object[]{
                    document.get("Código de Producto:"),
                    document.get("Producto:"),
                    document.get("Stock:"),
                    document.get("Precio:")
                });
            }
            jTableEliminar.setModel(tableModel);
            jTableEliminar.revalidate();
            jTableEliminar.repaint();
        }        // TODO add your handling code here:
    }//GEN-LAST:event_busquedaelimActionPerformed
    private void eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarActionPerformed
     String cod = codel.getText();
        if (!cod.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }try (MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017")) {
            MongoDatabase database = mongoClient.getDatabase("InterfacesLab2");
        MongoCollection<Document> collection = database.getCollection("Archivos");
        MongoCollection<Document> collectionn = database.getCollection("Comestibles");
        MongoCollection<Document> collectionnn = database.getCollection("Nocomestibles");
        Document filter = new Document("Código de Producto:", cod);
        collection.deleteOne(filter);
        collectionn.deleteOne(filter);
        collectionnn.deleteOne(filter);
        JOptionPane.showMessageDialog(this, "El producto a sido eliminado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
     } catch (Exception e) {
        e.printStackTrace();
    }
    }//GEN-LAST:event_eliminarActionPerformed
    private void busquedaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_busquedaActionPerformed
        String cod = stock.getText();
        if (!cod.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("InterfacesLab2");
        MongoCollection<Document> collectionn = database.getCollection("Archivos");

        Document query = new Document("Código de Producto:", cod);
        long count = collectionn.countDocuments(query);
        if (count <= 0) {
            JOptionPane.showMessageDialog(this, "El código ingresado no a sido registrado", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            DefaultTableModel tableModel = (DefaultTableModel) jTableStock.getModel();
            tableModel.setRowCount(0);
            FindIterable<Document> documents = collectionn.find(query);
            for (Document document : documents) {
                tableModel.addRow(new Object[]{
                    document.get("Código de Producto:"),
                    document.get("Producto:"),
                    document.get("Stock:"),
                    document.get("Precio:")
                });
            }
            jTableStock.setModel(tableModel);
            jTableStock.revalidate();
            jTableStock.repaint();
        }
    }//GEN-LAST:event_busquedaActionPerformed
    private void guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarActionPerformed
        String cod = stock.getText();
        String nuevoStock = nuevostock.getText();
        try {
            int stockr = Integer.parseInt(nuevoStock);
            if (stockr < 1 || stockr > 1000) {
                JOptionPane.showMessageDialog(this, "La cantidad de stock debe ser un número positivo entre 1 y 1000", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La cantidad de stock debe ser un número válido entre 1 y 1000", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("InterfacesLab2");
        MongoCollection<Document> collectionn = database.getCollection("Archivos");
        MongoCollection<Document> collection = database.getCollection("Comestibles");
        MongoCollection<Document> collectionnn = database.getCollection("Nocomestibles");
        Document query = new Document("Código de Producto:", cod);
        long count = collectionn.countDocuments(query);
        if (count <= 0) {
            JOptionPane.showMessageDialog(this, "El código ingresado no ha sido registrado", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            Document updateDocument = new Document("$set", new Document("Stock:", nuevoStock));
            collectionn.updateOne(query, updateDocument);
            collection.updateOne(query, updateDocument);
            collectionnn.updateOne(query, updateDocument);
            JOptionPane.showMessageDialog(this, "Stock actualizado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
        stock.setText("");
        nuevostock.setText("");
    }//GEN-LAST:event_guardarActionPerformed
    private void nuevostockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nuevostockActionPerformed
    }//GEN-LAST:event_nuevostockActionPerformed
    private void busqueda2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_busqueda2ActionPerformed
        String coddi = cod3.getText();
        if (!coddi.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("InterfacesLab2");
        MongoCollection<Document> collectionn = database.getCollection("Archivos");

        Document query = new Document("Código de Producto:", coddi);
        long count = collectionn.countDocuments(query);
        if (count <= 0) {
            JOptionPane.showMessageDialog(this, "El código ingresado no a sido registrado", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            DefaultTableModel tableModel = (DefaultTableModel) jTablePrecio.getModel();
            tableModel.setRowCount(0);
            FindIterable<Document> documents = collectionn.find(query);
            for (Document document : documents) {
                tableModel.addRow(new Object[]{
                    document.get("Código de Producto:"),
                    document.get("Producto:"),
                    document.get("Stock:"),
                    document.get("Precio:")
                });}
            jTablePrecio.setModel(tableModel);
            jTablePrecio.revalidate();
            jTablePrecio.repaint();
        }
    }//GEN-LAST:event_busqueda2ActionPerformed
    private void guardarPrecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarPrecioActionPerformed
        String coddi = cod3.getText();
        String nuevoPre = nuevoPrecio.getText();
        try {
            float precio = Float.parseFloat(nuevoPre);
            if (precio < 0.1 || precio > 100) {
                JOptionPane.showMessageDialog(this, "El precio debe ser un valor positivo entre 0.1 y 100", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El precio debe de ser un numero", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!coddi.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("InterfacesLab2");
        MongoCollection<Document> collectionn = database.getCollection("Archivos");
        MongoCollection<Document> collection = database.getCollection("Comestibles");
        MongoCollection<Document> collectionnn = database.getCollection("Nocomestibles");

        Document query = new Document("Código de Producto:", coddi);
        long count = collectionn.countDocuments(query);

        if (count <= 0) {
            JOptionPane.showMessageDialog(this, "El código ingresado no ha sido registrado", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            Document updateDocument = new Document("$set", new Document("Precio:", nuevoPre));
            collectionn.updateOne(query, updateDocument);
            collection.updateOne(query, updateDocument);
            collectionnn.updateOne(query, updateDocument);
            JOptionPane.showMessageDialog(this, "Precio del producto actualizado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
        cod3.setText("");
        nuevoPrecio.setText("");
    }//GEN-LAST:event_guardarPrecioActionPerformed
    private void nuevoPrecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nuevoPrecioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nuevoPrecioActionPerformed
    private void busqueda1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_busqueda1ActionPerformed
        String codd = stock1.getText();
        if (!codd.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("InterfacesLab2");
        MongoCollection<Document> collectionn = database.getCollection("Archivos");

        Document query = new Document("Código de Producto:", codd);
        long count = collectionn.countDocuments(query);
        if (count <= 0) {
            JOptionPane.showMessageDialog(this, "El código ingresado no a sido registrado", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            DefaultTableModel tableModel = (DefaultTableModel) jTableNombre.getModel();
            tableModel.setRowCount(0);
            FindIterable<Document> documents = collectionn.find(query);
            for (Document document : documents) {
                tableModel.addRow(new Object[]{
                    document.get("Código de Producto:"),
                    document.get("Producto:"),
                    document.get("Stock:"),
                    document.get("Precio:")
                });  }
            jTableNombre.setModel(tableModel);
            jTableNombre.revalidate();
            jTableNombre.repaint();
        }  // TODO add your handling code here:
    }//GEN-LAST:event_busqueda1ActionPerformed
    private void guardarNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarNombreActionPerformed
        String codd = stock1.getText();
        String nuevoNom = nuevoNombre.getText();
        String Nombre = nuevoNom.substring(0, 1).toUpperCase() + nuevoNom.substring(1).toLowerCase();

        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("InterfacesLab2");
        MongoCollection<Document> collectionn = database.getCollection("Archivos");
        MongoCollection<Document> collection = database.getCollection("Comestibles");
        MongoCollection<Document> collectionnn = database.getCollection("Nocomestibles");

        Document query = new Document("Código de Producto:", codd);
        long count = collectionn.countDocuments(query);
        Document queryy = new Document("Producto:", Nombre);
        long counnt = collectionn.countDocuments(queryy);

        if (count <= 0) {
            JOptionPane.showMessageDialog(this, "El código ingresado no ha sido registrado", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            if(counnt <= 0){

                // Define la actualización que deseas realizar
                Document updateDocument = new Document("$set", new Document("Producto:", Nombre));
                // Realiza la actualización
                collectionn.updateOne(query, updateDocument);
                collection.updateOne(query, updateDocument);
                collectionnn.updateOne(query, updateDocument);
                JOptionPane.showMessageDialog(this, "Nombre del producto actualizado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(this, "El nombre ingresado ya existe para otro producto", "Error", JOptionPane.ERROR_MESSAGE);
            }}
        stock1.setText("");
        nuevoNombre.setText("");
    }//GEN-LAST:event_guardarNombreActionPerformed
    private void nuevoNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nuevoNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nuevoNombreActionPerformed
    private void cargarDatosDesdeMongoo() {
         FindIterable<Document> documents = mongoNocom.getAllDocumentscollectionn();
         DefaultTableModel tableModel = new DefaultTableModel();
         tableModel.setColumnIdentifiers(new String[]{ "Código de Producto","Producto","Stock", "Precio"});
         // Llena el modelo con los datos de MongoDB
         for (Document document : documents) {
             tableModel.addRow(new Object[]{
                 document.get("Código de Producto:"),
                 document.get("Producto:"),
                 document.get("Stock:"),
                 document.get("Precio:"),
             });} jTable1.setModel(tableModel);
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(StockM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(StockM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(StockM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(StockM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StockM().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button busqueda;
    private java.awt.Button busqueda1;
    private java.awt.Button busqueda2;
    private java.awt.Button busquedaelim;
    private java.awt.Button button1;
    private java.awt.Button button2;
    private javax.swing.JTextField cod3;
    private javax.swing.JTextField codel;
    private java.awt.Button eliminar;
    private java.awt.Button guardar;
    private java.awt.Button guardarNombre;
    private java.awt.Button guardarPrecio;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTabbedPane jTabbedPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTableEliminar;
    private javax.swing.JTable jTableNombre;
    private javax.swing.JTable jTablePrecio;
    private javax.swing.JTable jTableStock;
    private javax.swing.JTextField nuevoNombre;
    private javax.swing.JTextField nuevoPrecio;
    private javax.swing.JTextField nuevostock;
    private javax.swing.JTextField stock;
    private javax.swing.JTextField stock1;
    // End of variables declaration//GEN-END:variables
}
